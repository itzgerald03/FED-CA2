document.addEventListener("DOMContentLoaded", function () {
  var typed = new Typed("#typed-text", {
    strings: ["Hi, my name is Gerald."],
    typeSpeed: 50,
    backSpeed: 30,
    backDelay: 1500,
    loop: true,
    showCursor: false
  });
});


